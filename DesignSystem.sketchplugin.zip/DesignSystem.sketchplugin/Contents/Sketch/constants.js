var Constants = {    
  DOCUMENT_VERSION: "docVersion",  
  TAB_SIZE: 2,
  HOTSPOT_PADDING: 0,
  LAYER_LOGGING: false,
  LOGGING: false,  
  RESOURCES_FOLDER: "scripts",
};

var SettingKeys = {
  PLUGIN_PATH_TO_LESS: "pluginPathToLess", 
  PLUGIN_PATH_TO_TOKENS: "pluginPathToTokens", 
};
